#ifndef SNAKE_H
#define SNAKE_H
int snake();
int abs(int n);
#define LEFT 0
#define RIGHT 1
#define UP 2
#define DOWN 3

#endif