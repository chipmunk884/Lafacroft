#include <os.h>
char* itoa(int a)
{
  char *str = malloc(sizeof(char) * 50);;
  int i = (sizeof(char) * 50) - 1;
  do
  {
    str[--i] = '0' + a % 10;
  }
  while ((a = a / 10) && i >= 0);
  return &str[i];
}
int strlen(char *c)
{
  int i = 0;
  while (c[i] != '\0')
  {
      i++;
  }
  return i;
}