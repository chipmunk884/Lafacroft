#include <os.h>
#include "utils.h"
#include "keys.h"
#include "drawBlock.h"
#include "snake.h"
#include "itoa.h"
asm(".string \"PRG\"\n");
int main(void) 
{
  int i, size;
  showSimpleDialogBox(
    "Snake v0.1",
    "Snake v0.1, by Sam101 (aka Samuel L) \n"
    "Controls: \n"
    "Up/Down/Left/Right: Move \n"
    "Esc: Exit \n"
    "Press Ctrl to begin the game \n"
    "Thanks to:\n"
    "People from #ti for their help \n" 
    "All ndless team for their wonderful work"
  );
  clearScreen();
  //Initialise le genérater
  while (!isKeyCtrlPressed())
  {
      rand();
  }
  int score = snake();
  char *scorechar = itoa(score); 
  char boxchar[70] = "You Loose ! ! \n Score: ";
  size = strlen(scorechar);
  for (i = 23; i < (23 + size); i++)
  {
      boxchar[i] = scorechar[i - 23];
  }
  showSimpleDialogBox("Game Over.",boxchar);
  return 0;
}
