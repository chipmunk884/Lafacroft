#ifndef ITOA_H
#define ITOA_H
char* itoa(int a);
int strlen(char *c);
#endif