#ifndef DRAWBLOCK_H
#define DRAWBLOCK_H
/**
  * Change un block de 16x16 pixels.
  */
void draw16(int x, int y, int color);
#endif