int isKeyEscPressed();
int isKeyCtrlPressed();
int isKeyMajPressed();
int isKeyEnterPressed();
int isKeyLeftPressed();
int isKeyRightPressed();
int isKeyUpPressed();
int isKeyDownPressed();