#include "drawBlock.h"
#include "utils.h"
void draw16(int x, int y, int color)
{
    int i, j;
    for (i = (x * 16); i < ((x * 16) + 16); i++)
    {
	for (j = (y * 16); j < ((y * 16) + 16); j++)
	{
	  if ( (i < 320) && (j < 240) )
	  {
	    setPixel(i,j,color);
	  }
	}
    }
}