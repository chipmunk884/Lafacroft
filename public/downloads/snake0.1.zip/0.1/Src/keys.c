asm(".macro is_key_pressed row, column");
asm("ldr r0, =(0x900E0000 + \\row )");
asm("ldrh r0, [r0]");
asm("tst r0, \\column");
asm(".endm");

int isKeyEscPressed()
{
   asm("is_key_pressed 0x1c, #0b00010000000");
   asm("movne r0, #0x0");
   asm("moveq r0, #0x1");
}


int isKeyCtrlPressed()
{
   asm("is_key_pressed 0x1e, #0b001000000000");
   asm("movne r0, #0x0");
   asm("moveq r0, #0x1");
}

int isKeyMajPressed()
{
   asm("is_key_pressed 0x1a, #0b001000000000");
   asm("movne r0, #0x0");
   asm("moveq r0, #0x1");
}

int isKeyEnterPressed()
{
   asm("is_key_pressed 0x10, #0b000000000010");
   asm("movne r0, #0x0");
   asm("moveq r0, #0x1");
}


int isKeyLeftPressed()
{
   asm("is_key_pressed 0x1e, #0b000001000000");
   asm("movne r0, #0x0");
   asm("moveq r0, #0x1");
}

int isKeyRightPressed()
{
   asm("is_key_pressed 0x1e, #0b000000000100");
   asm("movne r0, #0x0");
   asm("moveq r0, #0x1");
}

int isKeyUpPressed()
{
   asm("is_key_pressed 0x1e, #0b000000000001");
   asm("movne r0, #0x0");
   asm("moveq r0, #0x1");
}

int isKeyDownPressed()
{
   asm("is_key_pressed 0x1e, #0b000000010000");
   asm("movne r0, #0x0");
   asm("moveq r0, #0x1");
}
