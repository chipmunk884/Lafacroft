gbc4nspire v0.8 - by calc84maniac, sponsored by Omnimaga and Outside the Box Programming

1) About
    gbc4nspire is a Game Boy and Game Boy Color emulator for the TI-Nspire and TI-Nspire CAS, written from scratch in ARM assembly.

2) Installation
    First, install Ndless so you can run third party programs. Ndless can be found here: http://www.ticalc.org/archives/files/fileinfo/426/42626.html
    Next, create a new folder on the device to hold the emulator and ROMs.
    Then, use the TI-Nspire Computer Link to send either gbc4nspire.tns or gbc4nspire_cas.tns, depending on which type of Nspire it is.
    Try running it from the My Documents menu. It should say that it cannot find any ROM files. Press ESC to exit.
    Note: It has not yet been tested on CAS, but it should work :)
    
3) Sending ROM files
    Take a gameboy ROM file and add a .tns extension. If you start with "rom.gb", you should end up with "rom.gb.tns".
    Please keep the filename less than 40 characters so the filename will fit on the TI-Nspire screen.
    Note: If you are using Windows, you may need to change your folder settings if you cannot see file extensions.
    Then, use the TI-Nspire Computer Link to send the ".gb.tns" or ".gbc.tns" file to your device, in the same folder as the emulator.
    You can currently only have 14 ROMs at a time due to the menu size. However, you can bypass this limit by creating another emulator folder.
    
4) Running ROM files
    Run the emulator. A menu should come up where you can select a ROM to run. Select a ROM and press ENTER or Click.
    In-game controls (note: the game buttons were strategically located so there are no issues with pressing more than one at once)
        Arrows = D-Pad
        Esc = A
        Tab = B
        Caps = Start
        Clear = Select
        
        ON = Quit (a .sav file is automatically generated if the ROM supports save games)
        e^x = Save state to file
        10^x = Load state from file
        +/- = Change contrast
        * = Hold for no frame limit (run as fast as possible)

5) Special thanks
    ExtendeD and geogeo, for creating Ndless
    Goplat, for creating a great TI-Nspire emulator and for help with OS routines
    Omnimaga, for being so awesome! http://www.omnimaga.org/

6) To Do
    Add a proper in-game menu.
    TI-84+ keypad support.
    Allow changing frameskip value (it is currently set at 4 to counteract the horrendous LCD blurring)
    Toggle FPS counter.
    Support running two ROMs at once and link the virtual Gameboys.
    Link two TI-Nspires?
    Sound?

7) Version history
    v0.8:
        First release.