
Thanks for using my program !

-----------

Function Analysis - NSpire CAS
Version 1.90 English

-----------


How to use it :

--> Only on TI-NSpire CAS ! <--

1) Transfer the program using TI NSpire Link
2) Open the document
3) In order to analyze a function, you have to enter its variable and its domain. For example, we'll take ln(x), defined on 0;+infinite. You will just have to enter :  analyze(ln(x),x,{0,+oo})
(oo bzing the symbole of infinite, obtained by pressing Ctrl-i , complex i). Same for the funciton f(x)=x^2 on the specific domain [0,100], just type: analyze(x^2,x,{0,100}).
4) The final given result is actually a matrix, due to a lack of programming capability on the NSpire. The matrix gives you the summary of what you need to know about the function. Zeros, Derivative, Limits, Variations...

Note : The program should work with most common functions. If you notice any weird issue, please fell free to contact me and report the issue :)

-----------

Adriweb
adrienbertrand@msn.com
http://www.adriweb.net
http://www.ti-bank.fr