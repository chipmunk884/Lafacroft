Radical Simplifier 1.0

by Sumarth Mehta

<== see the screenshots ==>

syntax: radsimp(x,y) , which equals x*sqrt(y)

the program will simplify the radical into simplest form

it works if x and y are whole numbers or fractions

it can simplify extremely lage radicals very fast

comments, questions, suggestions: sumarth.mehta@gmail.com