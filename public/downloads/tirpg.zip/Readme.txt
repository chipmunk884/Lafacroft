Thanks for downloading TI RPG!
Simply open the document to start.
All instructions are included with the document.
For any questions or comments, contact me at:
http://www.freewebs.com/superbany/
Thanks!