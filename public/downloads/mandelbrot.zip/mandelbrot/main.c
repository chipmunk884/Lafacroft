#include <os.h>
#include "utils.h"
#define MAX_ITER 16

asm(".string \"PRG\"\n");

int main(void) {
  int x, y, n, flag;
  float a, b, cx, cy, t, u;
  for (x = 0; x < 320; x++) {
    for (y = 0; y < 240; y++) {
      a = cx = (x - 160.0) / 80;
      b = cy = (y - 120.0) / 80;
      flag = 1;
      for (n = 0; n < MAX_ITER; n++) {
        u = a * a;
        t = b * b;
        if (u + t > 4) {
          flag = 0;
          break;
        }  
        b = 2 * a * b + cy;
        a = u - t + cx; 
      }
      if (flag) {
        setPixel(x, y, 0);
      } else {
        setPixel(x, y, 16 - n);
      }
    }
  }

  while (!isKeyPressed(KEY_NSPIRE_ESC)) {}
  return 0;
}
