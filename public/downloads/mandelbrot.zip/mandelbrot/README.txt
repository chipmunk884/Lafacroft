This is a simple Mandelbrot fractal for the TI-Nspire.
If you wish to compile the source, grab a copy of Ndless and put main.c into the src/arm/demo folder in the unzipped Ndless archive (replacing the main.c included with Ndless).
