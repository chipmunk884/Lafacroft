class AddTypeColumn < ActiveRecord::Migration
  def self.up
    add_column :posts, :timestamps, :timestamps
    add_column :posts, :type, :string
  end

  def self.down
    remove_column :posts, :timestamps
    remove_column :posts, :type
  end
end
