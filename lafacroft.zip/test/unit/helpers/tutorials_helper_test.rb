require 'test_helper'

class TutorialsHelperTest < ActionView::TestCase
end
