require 'test_helper'

class InfoHelperTest < ActionView::TestCase
end
