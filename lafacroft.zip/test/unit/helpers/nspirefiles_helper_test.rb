require 'test_helper'

class NspirefilesHelperTest < ActionView::TestCase
end
