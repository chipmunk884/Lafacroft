require 'test_helper'

class Admin::PostsHelperTest < ActionView::TestCase
end
