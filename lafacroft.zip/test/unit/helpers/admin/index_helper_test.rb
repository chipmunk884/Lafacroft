require 'test_helper'

class Admin::IndexHelperTest < ActionView::TestCase
end
