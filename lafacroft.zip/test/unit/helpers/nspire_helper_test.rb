require 'test_helper'

class NspireHelperTest < ActionView::TestCase
end
