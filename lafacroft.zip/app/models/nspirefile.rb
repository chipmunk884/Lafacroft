class Nspirefile < ActiveRecord::Base
end
