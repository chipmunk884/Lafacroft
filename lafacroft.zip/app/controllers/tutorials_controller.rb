class TutorialsController < ApplicationController
  def index
  end

end
