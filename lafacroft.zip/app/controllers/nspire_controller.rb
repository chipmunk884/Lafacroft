class NspireController < ApplicationController
  def index
    @nspirefiles = Nspirefile.find(:all)

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @nspirefile }
      end
  end
end
