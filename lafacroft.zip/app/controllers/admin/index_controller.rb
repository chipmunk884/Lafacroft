class Admin::IndexController < ApplicationController
  def index
  end

end
