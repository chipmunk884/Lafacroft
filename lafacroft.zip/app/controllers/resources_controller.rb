class ResourcesController < ApplicationController
  def index
  end

end
