class InfoController < ApplicationController
  def contact
  end

  def about
  end

end
