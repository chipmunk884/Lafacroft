module Admin::IndexHelper
end
