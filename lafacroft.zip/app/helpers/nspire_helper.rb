module NspireHelper
end
